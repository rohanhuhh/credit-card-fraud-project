
import numpy as np
from sklearn.datasets import make_classification
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import roc_auc_score, classification_report
from imblearn.over_sampling import SMOTE
import joblib

print("Generating synthetic credit card dataset (highly imbalanced)...")

X, y = make_classification(
    n_samples=5000,
    n_features=20,
    n_informative=10,
    weights=[0.97, 0.03],  # 3% fraud
    random_state=42
)

print(f"Class distribution before SMOTE: {np.bincount(y)}")

# Handle imbalance
smote = SMOTE(random_state=42)
X_res, y_res = smote.fit_resample(X, y)
print(f"Class distribution after SMOTE: {np.bincount(y_res)}")

# Train-test split
X_train, X_test, y_train, y_test = train_test_split(
    X_res, y_res, test_size=0.2, random_state=42, stratify=y_res
)

# Model
model = LogisticRegression(max_iter=1000)
model.fit(X_train, y_train)

# Evaluation
y_prob = model.predict_proba(X_test)[:,1]
auc = roc_auc_score(y_test, y_prob)

print("\n=== MODEL RESULTS ===")
print("ROC-AUC:", round(auc, 4))
print("\nClassification Report:")
print(classification_report(y_test, model.predict(X_test)))

# Save model
joblib.dump(model, "fraud_model.pkl")
print("Model saved as fraud_model.pkl")
